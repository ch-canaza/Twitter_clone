// let word;
// $(':input').bind('keypress keydown keyup change',function(){
//   let word = $("#keyword").val();
//   console.log(word);
//   $("#searchlink").attr("href","/users/" + word.toString()) + "/follow";
//   console.log('word');

//  });
// console.log('word')
// console.log(word)
let user_name1; 
function formdata()
{
let user_name1 = document.getElementById("keyword").value;
//var lastname1= document.getElementById("lastname").value;
document.writeln("<h1>Confirmation Page</h1><br>");
document.writeln("Thank you for completing this form.<br><br>");
document.writeln("The first name you entered is " + user_name + "<br>");
//document.writeln("The last name you entered is " + lastname);
console.log(user_name1)
}
console.log(user_name1)
